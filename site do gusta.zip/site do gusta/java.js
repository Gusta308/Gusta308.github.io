document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Personalização salva com sucesso!');
});
